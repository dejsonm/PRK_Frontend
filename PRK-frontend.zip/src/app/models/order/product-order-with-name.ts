export class ProductOrderWithName {
  public productName!: string
  public productId!: number
  public productQuantity!: number
}
