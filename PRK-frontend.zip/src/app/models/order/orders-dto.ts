import {OrderDto} from "./order-dto";

export class OrdersDto {
  public orders!: OrderDto[];
}
