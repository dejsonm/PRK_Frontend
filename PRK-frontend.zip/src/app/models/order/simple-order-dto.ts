export class SimpleOrderDto {
  public orderDate!: string
  public orderId!: number
  public status!: string
}
