export class OrderStatus {
  static readonly Statuses: string[] = ['CANCEL','IN_PROGRESS','DONE']
}
