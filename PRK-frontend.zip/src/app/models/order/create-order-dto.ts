import {ProductOrderDto} from "./product-order-dto";

export class CreateOrderDto {
  public products!: ProductOrderDto[]
}
