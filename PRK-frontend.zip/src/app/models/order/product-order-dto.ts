export class ProductOrderDto {
  public productId!: number
  public productQuantity!: number
}
