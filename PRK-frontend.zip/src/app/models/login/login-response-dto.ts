export class LoginResponseDto {
 public admin!: boolean
 public token!: string
}
