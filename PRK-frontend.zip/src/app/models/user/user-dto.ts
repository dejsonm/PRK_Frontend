export class UserDto {
 public id!: number
 public lastName!:string
  public name!:string
  public userName!:string
}
