import {UserDto} from "./user-dto";

export class UsersDto {
  public users!: UserDto[]
}
