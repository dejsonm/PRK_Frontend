export class ProductDto {
  public productCurrency!: string;
  public productId!: number;
  public productName!: string;
  public productPrice!: number;
  public productQuantity!: number;
}
