export class ProductCurrencies {
  static readonly Currencies: string[] = ['EU','USD','PLN']
}
