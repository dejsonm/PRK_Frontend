export class ProductResponseDto {
}
