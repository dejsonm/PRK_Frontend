import {ProductDto} from "./product-dto";

export class ProductsDto {
  public products!: ProductDto[];
}
