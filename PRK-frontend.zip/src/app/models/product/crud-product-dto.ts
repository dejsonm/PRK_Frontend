export class CrudProductDto {
  public productCurrency!: string;
  public productName!: string;
  public productPrice!: number;
  public productQuantity!: number;
}
