export const environment = {
  production: true,

  baseUrl: 'http://localhost:8080/'
};
